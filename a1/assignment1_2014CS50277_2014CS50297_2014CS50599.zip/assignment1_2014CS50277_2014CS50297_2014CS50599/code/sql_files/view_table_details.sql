SELECT * FROM course;
SELECT * FROM teacher;
SELECT * FROM student;
SELECT * FROM teaches;
SELECT * FROM registers;
SELECT * FROM section;