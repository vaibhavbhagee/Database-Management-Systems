\copy student to '/tmp/student.csv' DELIMITER ',';
\copy teacher to '/tmp/teacher.csv' DELIMITER ',';
\copy course to '/tmp/course.csv' DELIMITER ',';
\copy teaches to '/tmp/teaches.csv' DELIMITER ',';
\copy registers to '/tmp/registers.csv' DELIMITER ',';
\copy section to '/tmp/section.csv' DELIMITER ',';