\timing

-------------------------------------------------------------------------------------
-- INSERT STATEMENTS TO POPULATE THE TABLES
-------------------------------------------------------------------------------------

INSERT INTO student VALUES ('S0','Pankaj Corvuss Kumar');
INSERT INTO student VALUES ('S1','Natwarlal expunging Bhide');
INSERT INTO student VALUES ('S2','Sonalika prestigious Sodhi');
INSERT INTO student VALUES ('S3','Tipendra stinks Gada');
INSERT INTO student VALUES ('S4','Sonalika chemistry Undhaiwala');
INSERT INTO student VALUES ('S5','Pankaj dispensing Gada');
INSERT INTO student VALUES ('S6','Pankaj Urumqi Sodhi');
INSERT INTO student VALUES ('S7','Uvuvwevwevwe wobbles Sodhi');
INSERT INTO student VALUES ('S8','Sonalika cirrhosiss Bhide');
INSERT INTO student VALUES ('S9','Sonalika asseverate Ossas');
INSERT INTO teacher VALUES ('T0','John gutters Gadot');
INSERT INTO teacher VALUES ('T1','Muhammed chocks Singh');
INSERT INTO teacher VALUES ('T2','Vladimir archdioceses Kumar');
INSERT INTO teacher VALUES ('T3','Jethalal Chandras Singh');
INSERT INTO teacher VALUES ('T4','Jethalal raggedly Khan');
INSERT INTO teacher VALUES ('T5','Ram coinciding Khan');
INSERT INTO teacher VALUES ('T6','Vladimir disenfranchises Poppins');
INSERT INTO teacher VALUES ('T7','John fountains Khan');
INSERT INTO teacher VALUES ('T8','Hirohito medication Kumar');
INSERT INTO teacher VALUES ('T9','Vladimir artsy Mizuhara');
INSERT INTO course VALUES ('IRY743','Introduction to flossed');
INSERT INTO course VALUES ('SUD211','Introduction to Helen');
INSERT INTO course VALUES ('GTE043','Introduction to shaded');
INSERT INTO course VALUES ('URG062','Introduction to baptisms');
INSERT INTO course VALUES ('NBR843','Introduction to parodys');
INSERT INTO course VALUES ('QCM751','Introduction to oblations');
INSERT INTO course VALUES ('BSQ386','Introduction to reworking');
INSERT INTO course VALUES ('KOE444','Introduction to Lipizzaner');
INSERT INTO course VALUES ('NTE882','Introduction to concordances');
INSERT INTO course VALUES ('THC721','Introduction to Philistine');
INSERT INTO registers VALUES ('S0','IRY743');
INSERT INTO registers VALUES ('S0','SUD211');
INSERT INTO registers VALUES ('S0','GTE043');
INSERT INTO registers VALUES ('S0','URG062');
INSERT INTO registers VALUES ('S0','NBR843');
INSERT INTO registers VALUES ('S0','QCM751');
INSERT INTO registers VALUES ('S0','BSQ386');
INSERT INTO registers VALUES ('S0','KOE444');
INSERT INTO registers VALUES ('S0','NTE882');
INSERT INTO registers VALUES ('S0','THC721');
INSERT INTO registers VALUES ('S1','IRY743');
INSERT INTO registers VALUES ('S1','SUD211');
INSERT INTO registers VALUES ('S1','GTE043');
INSERT INTO registers VALUES ('S1','URG062');
INSERT INTO registers VALUES ('S1','NBR843');
INSERT INTO registers VALUES ('S1','QCM751');
INSERT INTO registers VALUES ('S1','BSQ386');
INSERT INTO registers VALUES ('S1','KOE444');
INSERT INTO registers VALUES ('S1','NTE882');
INSERT INTO registers VALUES ('S1','THC721');
INSERT INTO registers VALUES ('S2','IRY743');
INSERT INTO registers VALUES ('S2','SUD211');
INSERT INTO registers VALUES ('S2','GTE043');
INSERT INTO registers VALUES ('S2','URG062');
INSERT INTO registers VALUES ('S2','NBR843');
INSERT INTO registers VALUES ('S2','QCM751');
INSERT INTO registers VALUES ('S2','BSQ386');
INSERT INTO registers VALUES ('S2','KOE444');
INSERT INTO registers VALUES ('S2','NTE882');
INSERT INTO registers VALUES ('S2','THC721');
INSERT INTO registers VALUES ('S3','IRY743');
INSERT INTO registers VALUES ('S3','SUD211');
INSERT INTO registers VALUES ('S3','GTE043');
INSERT INTO registers VALUES ('S3','URG062');
INSERT INTO registers VALUES ('S3','NBR843');
INSERT INTO registers VALUES ('S3','QCM751');
INSERT INTO registers VALUES ('S3','BSQ386');
INSERT INTO registers VALUES ('S3','KOE444');
INSERT INTO registers VALUES ('S3','NTE882');
INSERT INTO registers VALUES ('S3','THC721');
INSERT INTO registers VALUES ('S4','IRY743');
INSERT INTO registers VALUES ('S4','SUD211');
INSERT INTO registers VALUES ('S4','GTE043');
INSERT INTO registers VALUES ('S4','URG062');
INSERT INTO registers VALUES ('S4','NBR843');
INSERT INTO registers VALUES ('S4','QCM751');
INSERT INTO registers VALUES ('S4','BSQ386');
INSERT INTO registers VALUES ('S4','KOE444');
INSERT INTO registers VALUES ('S4','NTE882');
INSERT INTO registers VALUES ('S4','THC721');
INSERT INTO registers VALUES ('S5','IRY743');
INSERT INTO registers VALUES ('S5','SUD211');
INSERT INTO registers VALUES ('S5','GTE043');
INSERT INTO registers VALUES ('S5','URG062');
INSERT INTO registers VALUES ('S5','NBR843');
INSERT INTO registers VALUES ('S5','QCM751');
INSERT INTO registers VALUES ('S5','BSQ386');
INSERT INTO registers VALUES ('S5','KOE444');
INSERT INTO registers VALUES ('S5','NTE882');
INSERT INTO registers VALUES ('S5','THC721');
INSERT INTO registers VALUES ('S6','IRY743');
INSERT INTO registers VALUES ('S6','SUD211');
INSERT INTO registers VALUES ('S6','GTE043');
INSERT INTO registers VALUES ('S6','URG062');
INSERT INTO registers VALUES ('S6','NBR843');
INSERT INTO registers VALUES ('S6','QCM751');
INSERT INTO registers VALUES ('S6','BSQ386');
INSERT INTO registers VALUES ('S6','KOE444');
INSERT INTO registers VALUES ('S6','NTE882');
INSERT INTO registers VALUES ('S6','THC721');
INSERT INTO registers VALUES ('S7','IRY743');
INSERT INTO registers VALUES ('S7','SUD211');
INSERT INTO registers VALUES ('S7','GTE043');
INSERT INTO registers VALUES ('S7','URG062');
INSERT INTO registers VALUES ('S7','NBR843');
INSERT INTO registers VALUES ('S7','QCM751');
INSERT INTO registers VALUES ('S7','BSQ386');
INSERT INTO registers VALUES ('S7','KOE444');
INSERT INTO registers VALUES ('S7','NTE882');
INSERT INTO registers VALUES ('S7','THC721');
INSERT INTO registers VALUES ('S8','IRY743');
INSERT INTO registers VALUES ('S8','SUD211');
INSERT INTO registers VALUES ('S8','GTE043');
INSERT INTO registers VALUES ('S8','URG062');
INSERT INTO registers VALUES ('S8','NBR843');
INSERT INTO registers VALUES ('S8','QCM751');
INSERT INTO registers VALUES ('S8','BSQ386');
INSERT INTO registers VALUES ('S8','KOE444');
INSERT INTO registers VALUES ('S8','NTE882');
INSERT INTO registers VALUES ('S8','THC721');
INSERT INTO registers VALUES ('S9','IRY743');
INSERT INTO registers VALUES ('S9','SUD211');
INSERT INTO registers VALUES ('S9','GTE043');
INSERT INTO registers VALUES ('S9','URG062');
INSERT INTO registers VALUES ('S9','NBR843');
INSERT INTO registers VALUES ('S9','QCM751');
INSERT INTO registers VALUES ('S9','BSQ386');
INSERT INTO registers VALUES ('S9','KOE444');
INSERT INTO registers VALUES ('S9','NTE882');
INSERT INTO registers VALUES ('S9','THC721');
INSERT INTO teaches VALUES ('IRY743','T0');
INSERT INTO teaches VALUES ('SUD211','T0');
INSERT INTO teaches VALUES ('GTE043','T0');
INSERT INTO teaches VALUES ('URG062','T0');
INSERT INTO teaches VALUES ('NBR843','T0');
INSERT INTO teaches VALUES ('QCM751','T0');
INSERT INTO teaches VALUES ('BSQ386','T0');
INSERT INTO teaches VALUES ('KOE444','T0');
INSERT INTO teaches VALUES ('NTE882','T0');
INSERT INTO teaches VALUES ('THC721','T0');
INSERT INTO teaches VALUES ('IRY743','T1');
INSERT INTO teaches VALUES ('SUD211','T1');
INSERT INTO teaches VALUES ('GTE043','T1');
INSERT INTO teaches VALUES ('URG062','T1');
INSERT INTO teaches VALUES ('NBR843','T1');
INSERT INTO teaches VALUES ('QCM751','T1');
INSERT INTO teaches VALUES ('BSQ386','T1');
INSERT INTO teaches VALUES ('KOE444','T1');
INSERT INTO teaches VALUES ('NTE882','T1');
INSERT INTO teaches VALUES ('THC721','T1');
INSERT INTO teaches VALUES ('IRY743','T2');
INSERT INTO teaches VALUES ('SUD211','T2');
INSERT INTO teaches VALUES ('GTE043','T2');
INSERT INTO teaches VALUES ('URG062','T2');
INSERT INTO teaches VALUES ('NBR843','T2');
INSERT INTO teaches VALUES ('QCM751','T2');
INSERT INTO teaches VALUES ('BSQ386','T2');
INSERT INTO teaches VALUES ('KOE444','T2');
INSERT INTO teaches VALUES ('NTE882','T2');
INSERT INTO teaches VALUES ('THC721','T2');
INSERT INTO teaches VALUES ('IRY743','T3');
INSERT INTO teaches VALUES ('SUD211','T3');
INSERT INTO teaches VALUES ('GTE043','T3');
INSERT INTO teaches VALUES ('URG062','T3');
INSERT INTO teaches VALUES ('NBR843','T3');
INSERT INTO teaches VALUES ('QCM751','T3');
INSERT INTO teaches VALUES ('BSQ386','T3');
INSERT INTO teaches VALUES ('KOE444','T3');
INSERT INTO teaches VALUES ('NTE882','T3');
INSERT INTO teaches VALUES ('THC721','T3');
INSERT INTO teaches VALUES ('IRY743','T4');
INSERT INTO teaches VALUES ('SUD211','T4');
INSERT INTO teaches VALUES ('GTE043','T4');
INSERT INTO teaches VALUES ('URG062','T4');
INSERT INTO teaches VALUES ('NBR843','T4');
INSERT INTO teaches VALUES ('QCM751','T4');
INSERT INTO teaches VALUES ('BSQ386','T4');
INSERT INTO teaches VALUES ('KOE444','T4');
INSERT INTO teaches VALUES ('NTE882','T4');
INSERT INTO teaches VALUES ('THC721','T4');
INSERT INTO teaches VALUES ('IRY743','T5');
INSERT INTO teaches VALUES ('SUD211','T5');
INSERT INTO teaches VALUES ('GTE043','T5');
INSERT INTO teaches VALUES ('URG062','T5');
INSERT INTO teaches VALUES ('NBR843','T5');
INSERT INTO teaches VALUES ('QCM751','T5');
INSERT INTO teaches VALUES ('BSQ386','T5');
INSERT INTO teaches VALUES ('KOE444','T5');
INSERT INTO teaches VALUES ('NTE882','T5');
INSERT INTO teaches VALUES ('THC721','T5');
INSERT INTO teaches VALUES ('IRY743','T6');
INSERT INTO teaches VALUES ('SUD211','T6');
INSERT INTO teaches VALUES ('GTE043','T6');
INSERT INTO teaches VALUES ('URG062','T6');
INSERT INTO teaches VALUES ('NBR843','T6');
INSERT INTO teaches VALUES ('QCM751','T6');
INSERT INTO teaches VALUES ('BSQ386','T6');
INSERT INTO teaches VALUES ('KOE444','T6');
INSERT INTO teaches VALUES ('NTE882','T6');
INSERT INTO teaches VALUES ('THC721','T6');
INSERT INTO teaches VALUES ('IRY743','T7');
INSERT INTO teaches VALUES ('SUD211','T7');
INSERT INTO teaches VALUES ('GTE043','T7');
INSERT INTO teaches VALUES ('URG062','T7');
INSERT INTO teaches VALUES ('NBR843','T7');
INSERT INTO teaches VALUES ('QCM751','T7');
INSERT INTO teaches VALUES ('BSQ386','T7');
INSERT INTO teaches VALUES ('KOE444','T7');
INSERT INTO teaches VALUES ('NTE882','T7');
INSERT INTO teaches VALUES ('THC721','T7');
INSERT INTO teaches VALUES ('IRY743','T8');
INSERT INTO teaches VALUES ('SUD211','T8');
INSERT INTO teaches VALUES ('GTE043','T8');
INSERT INTO teaches VALUES ('URG062','T8');
INSERT INTO teaches VALUES ('NBR843','T8');
INSERT INTO teaches VALUES ('QCM751','T8');
INSERT INTO teaches VALUES ('BSQ386','T8');
INSERT INTO teaches VALUES ('KOE444','T8');
INSERT INTO teaches VALUES ('NTE882','T8');
INSERT INTO teaches VALUES ('THC721','T8');
INSERT INTO teaches VALUES ('IRY743','T9');
INSERT INTO teaches VALUES ('SUD211','T9');
INSERT INTO teaches VALUES ('GTE043','T9');
INSERT INTO teaches VALUES ('URG062','T9');
INSERT INTO teaches VALUES ('NBR843','T9');
INSERT INTO teaches VALUES ('QCM751','T9');
INSERT INTO teaches VALUES ('BSQ386','T9');
INSERT INTO teaches VALUES ('KOE444','T9');
INSERT INTO teaches VALUES ('NTE882','T9');
INSERT INTO teaches VALUES ('THC721','T9');
INSERT INTO section VALUES ('A','IRY743');
INSERT INTO section VALUES ('A','SUD211');
INSERT INTO section VALUES ('A','GTE043');
INSERT INTO section VALUES ('A','URG062');
INSERT INTO section VALUES ('A','NBR843');
INSERT INTO section VALUES ('A','QCM751');
INSERT INTO section VALUES ('A','BSQ386');
INSERT INTO section VALUES ('A','KOE444');
INSERT INTO section VALUES ('A','NTE882');
INSERT INTO section VALUES ('A','THC721');
INSERT INTO section VALUES ('B','IRY743');
INSERT INTO section VALUES ('B','SUD211');
INSERT INTO section VALUES ('B','GTE043');
INSERT INTO section VALUES ('B','URG062');
INSERT INTO section VALUES ('B','NBR843');
INSERT INTO section VALUES ('B','QCM751');
INSERT INTO section VALUES ('B','BSQ386');
INSERT INTO section VALUES ('B','KOE444');
INSERT INTO section VALUES ('B','NTE882');
INSERT INTO section VALUES ('B','THC721');
INSERT INTO section VALUES ('C','IRY743');
INSERT INTO section VALUES ('C','SUD211');
INSERT INTO section VALUES ('C','GTE043');
INSERT INTO section VALUES ('C','URG062');
INSERT INTO section VALUES ('C','NBR843');
INSERT INTO section VALUES ('C','QCM751');
INSERT INTO section VALUES ('C','BSQ386');
INSERT INTO section VALUES ('C','KOE444');
INSERT INTO section VALUES ('C','NTE882');
INSERT INTO section VALUES ('C','THC721');
INSERT INTO section VALUES ('D','IRY743');
INSERT INTO section VALUES ('D','SUD211');
INSERT INTO section VALUES ('D','GTE043');
INSERT INTO section VALUES ('D','URG062');
INSERT INTO section VALUES ('D','NBR843');
INSERT INTO section VALUES ('D','QCM751');
INSERT INTO section VALUES ('D','BSQ386');
INSERT INTO section VALUES ('D','KOE444');
INSERT INTO section VALUES ('D','NTE882');
INSERT INTO section VALUES ('D','THC721');

-------------------------------------------------------------------------------------

-- Causes no change
-- DELETE FROM section;
-- DELETE FROM registers;
-- DELETE FROM teaches;

-------------------------------------------------------------------------------------

-- Checks Referential integrity (Should empty all the tables after execution)
-- DELETE FROM course;
-- DELETE FROM teacher;
-- DELETE FROM student;

----------------------------------------------------------------------------------------
-- FOLLOWING TEST CASES CHECK FOR VIOLATION OF CONSTRAINTS AND ARE BOUND TO THROW ERRORS
----------------------------------------------------------------------------------------

-- Checks for section (1: Checks for duplicates, 2: Checks for section not in (A,B,C,D), 3: Checks for foreign key constraint for course)
-- INSERT INTO section VALUES ('A','IRY743');
-- INSERT INTO section VALUES ('E','IRY743');
-- INSERT INTO section VALUES ('A','AAAAAA');

-------------------------------------------------------------------------------------

-- Checks for teaches (1: Checks for duplicates, 2: Checks for foreign key constraint for teacher, 3: Checks for foreign key constraint for course)
-- INSERT INTO teaches VALUES ('URG062','T9');
-- INSERT INTO teaches VALUES ('URG062','T10');
-- INSERT INTO teaches VALUES ('AAAAAA','T9');

-------------------------------------------------------------------------------------

-- Checks for registers (1: Checks for duplicates, 2: Checks for foreign key constraint for teacher, 3: Checks for foreign key constraint for student)
-- INSERT INTO registers VALUES ('S8','QCM751');
-- INSERT INTO registers VALUES ('S8','AAAAAA');
-- INSERT INTO registers VALUES ('S10','QCM751');

-------------------------------------------------------------------------------------

-- Checks for DELETE statements (checks foreign key constraint for a single element)
-- DELETE FROM course WHERE course_id = 'IRY743';

-- DELETE FROM teacher WHERE teacher_id = 'T9';
-- INSERT INTO teaches VALUES ('IRY743','T9');

-- DELETE FROM student WHERE student_id = 'S8';
-- INSERT INTO registers VALUES ('S8','IRY743');

-------------------------------------------------------------------------------------

-- Checks for UPDATE statements (checks for update cascade)
UPDATE teacher SET teacher_id = 'T10' WHERE teacher_id = 'T9';
UPDATE course SET course_id = 'AAA000' WHERE course_id = 'QCM751';
UPDATE student SET student_id = 'T10' WHERE student_id = 'T9';