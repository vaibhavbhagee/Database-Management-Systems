\timing
\copy student from '/tmp/student.csv' DELIMITER ',';
\copy teacher from '/tmp/teacher.csv' DELIMITER ',';
\copy course from '/tmp/course.csv' DELIMITER ',';
\copy teaches from '/tmp/teaches.csv' DELIMITER ',';
\copy registers from '/tmp/registers.csv' DELIMITER ',';
\copy section from '/tmp/section.csv' DELIMITER ',';